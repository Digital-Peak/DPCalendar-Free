Hello
This is the source of DPCalendar, a Joomla calendar and event manager. Here you will find the component, some modules and plugins of DPCalendar.

### PREREQUISITS
- Joomla 3.7 and above
- MySQL >= 5.5.0
- PHP >= 5.5.9

### INSTALLATION
To install DPCalendar extract the component, your desired modules and the plugins zip files and install them with the Joomla installer.You can also install the whole suite with all extensions trough the Joomla installer. After a successful installation configure the component, modules and the plugins and publish them.

### UPGRADE
To upgrade DPCalendar from an earlier version, just install the suite or individual extensions with the joomla installer, DPCalendar will handle the upgrade procedure by itself.

### DOCUMENTATION
Check https://joomla.digital-peak.com for the documentation and new releases.

### Contribute
As we believe strongly in open source, we provide this extension for free. So we encourage you to open a pull request when you want to add a new feature or provide a bug fix.

Have fun
The Digital Peak team